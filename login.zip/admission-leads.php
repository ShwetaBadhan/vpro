<?php
error_reporting(E_ALL);
session_start();

if (!isset($_SESSION["login_user"])) {
    header("location: index.php");
}

include("db/config.php");
$query = "
SELECT 
    admission_enquiry.admission_id,
    admission_enquiry.name,
    admission_enquiry.email,
    admission_enquiry.mobile,
   	admission_enquiry.course_type,
    admission_enquiry.remarks,
    admission_enquiry.state,
    admission_enquiry.city,
    admission_enquiry.lead_status,
    admission_enquiry.date
FROM 
    admission_enquiry


ORDER BY 
    admission_enquiry.date DESC
";



$result = mysqli_query($db, $query);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['editleads'])) {
    $leadid = base64_decode($_POST['admission_id']);
    $leadstatus = $_POST['lead_status'];
    $remarks = trim($_POST['remarks']); // Get remarks

    if (empty($leadstatus)) {
        die("Lead status is required.");
    }

    $query = "UPDATE admission_enquiry SET lead_status = ?, remarks = ? WHERE admission_id = ?";

    if ($stmt = mysqli_prepare($db, $query)) {
        mysqli_stmt_bind_param($stmt, "ssi", $leadstatus, $remarks, $leadid);

        if (mysqli_stmt_execute($stmt)) {
            header('Location: admission-leads.php');
            exit;
        } else {
            echo "Error updating lead status: " . mysqli_error($db);
        }

        mysqli_stmt_close($stmt);
    } else {
        echo "Error preparing statement: " . mysqli_error($db);
    }
}

// Fetch lead statuses
$query = "SELECT status_id, status_name FROM lead_status";
$status_result = mysqli_query($db, $query);
// Upload and process CSV

$uploadSuccess = false; // Default success flag

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['csv_file']) && $_FILES['csv_file']['error'] == 0) {
        $filename = $_FILES['csv_file']['tmp_name'];

        if (($handle = fopen($filename, "r")) !== FALSE) {
            $header = fgetcsv($handle); // Skip header row

            while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
                $name = $db->real_escape_string($data[0]);
                $email = $db->real_escape_string($data[1]);
                $phone = $db->real_escape_string($data[2]);
                $state = $db->real_escape_string($data[3]);
                $city = $db->real_escape_string($data[4]);
                $course_type = $db->real_escape_string($data[5]);
                $lead_status = $db->real_escape_string($data[6]);

                $sql = "INSERT INTO admission_enquiry 
                        (name, email, mobile, state, city, course_type, lead_status) 
                        VALUES ('$name', '$email', '$phone', '$state', '$city', '$course_type', '$lead_status')";

                if (!$db->query($sql)) {
                    // If there's an error with query execution, set failure flag
                    $uploadSuccess = false;
                    break;
                }
            }

            fclose($handle);

            // If no error during file processing, set success flag
            $uploadSuccess = true;
        } else {
            $uploadSuccess = false;
        }
    } else {
        $uploadSuccess = false;
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<head>
    <title>Admission Leads</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="description" content="" />
    <meta name="keywords" content="">
    <meta name="author" content="Codedthemes" />

    <link rel="icon" href="assets/images/favicon.ico" type="image/x-icon">

    <link rel="stylesheet" href="assets/css/plugins/dataTables.bootstrap4.min.css">

    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .custom-upload-btn {
            display: inline-block;
            background-color: rgb(255, 208, 67);
            color: #fff;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
        }

        .custom-upload-btn i {
            margin-right: 5px;
            vertical-align: middle;
        }

        .btn-custom {
            display: inline-block;
            background-color: rgb(142, 185, 42);
            color: #fff;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            margin-right: 10px;
            text-decoration: none;
        }

        .btn-custom i {
            margin-right: 5px;
            vertical-align: middle;
        }

        input[type="file"] {
            display: none;
        }
    </style>
    <!-- SweetAlert2 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.0/dist/sweetalert2.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/2.3.0/css/dataTables.dataTables.css" />
</head>

<body class="">

    <div class="loader-bg">
        <div class="loader-track">
            <div class="loader-fill"></div>
        </div>
    </div>

    <!-- Header -->
    <?php
    include("header.php");
    ?>
    <!-- /Header -->

    <!-- navbar -->
    <?php
    include("navbar.php");
    ?>
    <!-- /navbar -->

    <section class="pcoded-main-container">
        <div class="pcoded-content">

            <div class="page-header">
                <div class="page-block">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="page-header-title">
                                <h5 class="m-b-10">Admission Lead
                                </h5>
                            </div>

                        </div>
                    </div>
                </div>
            </div>


            <div class="row">

                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-header table-card-header">

                            <form action="" method="POST" enctype="multipart/form-data" id="leadForm">
                                <input type="file" name="csv_file" id="csv_file" accept=".csv" required>

                                <label for="csv_file" class="custom-upload-btn">
                                    <i class="feather icon-upload"></i> Upload Leads
                                </label>
                                <!-- Download Sample CSV Button -->
                                <a href="assets/sample.csv" download class="btn-custom">
                                    <i class="feather icon-download"></i> Download Sample CSV
                                </a>
                            </form>

                        </div>
                        <div class="card-body">
                            <form method="POST" action="download-leads.php" class="d-flex align-items-center gap-2 flex-wrap">


                                <div class="form-group mb-2 mr-2">
                                    <label for="dateFrom">Date From:</label>
                                    <input type="date" class="form-control w-auto" name="dateFrom" id="dateFrom">
                                </div>

                                <div class="form-group mb-2 mr-2">
                                    <label for="dateTo">Date To:</label>
                                    <input type="date" class="form-control w-auto" name="dateTo" id="dateTo">
                                </div>
                                <div class="form-group mb-2 mr-2">
                                    <label for="statusFilter">Lead Status:</label>
                                    <select id="statusFilter" name="status" class="form-control w-auto">
                                        <option value="">Select Lead Status</option>
                                        <!-- Options will be populated dynamically from the database -->
                                    </select>
                                </div>
                                <div class="form-group mb-2 mr-2 mt-4">
                                    <button type="submit" class="btn btn-primary" name="download"><i class='feather icon-download'></i> Download Leads</button>
                                </div>

                            </form>

                            <form id="deleteForm" action="delete-leads.php" method="post">
                                <div class="d-flex align-items-center mb-2">
                                    <button type="button" id="deleteSelected" class="btn btn-danger mr-2">
                                        <i class='feather icon-trash'></i> Delete Selected
                                    </button>


                                </div>



                                <div class="dt-responsive table-responsive">

                                    <?php

                                    if (isset($_GET['status'])) {
                                        $st = $_GET['status'];
                                        $st1 = base64_decode($st);

                                        if ($st1 > 0) {
                                            echo " <div class='alert alert-success alert-dismissible fade show' role='alert' style='font-size:16px;' id='updateuser'>
  <strong><i class='feather icon-check'></i>Success!</strong>  Leads has been Restored Successfully.
  <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
    <span aria-hidden='true'>&times;</span>
  </button>
</div> ";
                                        } else {

                                            echo " <div class='alert alert-danger alert-dismissible fade show' role='alert' style='font-size:16px;' id='updateuser'>
  <strong>Error!</strong> Leads has been not Updated
  <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
    <span aria-hidden='true'>&times;</span>
  </button>
</div> ";
                                        }
                                    }

                                    ?>

                                    <?php
                                    //                                 echo '<a href="javascript:void(0)" id="basic-btn" class="btn btn-warning">
                                    //     <i class="feather icon-download"></i> Download Excel
                                    // </a>';
                                    echo '<table   class="table table-striped table-bordered nowrap" id="leadsTable">';
                                    echo "<thead>";
                                    echo "<tr>";
                                    echo "<th><input type='checkbox' id='selectAll' onclick='toggleCheckboxes(this)'> SELECT</th>";
                                    echo "<th>SNO</th>";
                                    echo "<th>NAME</th>";
                                   
                                    echo "<th>MOBILE NUMBER</th>";
                                    echo "<th>COURSES</th>";
                                    echo "<th>STATE</th>";
                                    echo "<th>CITY</th>";
                                     echo "<th>REMARKS</th>";
                                    echo "<th>LEAD STATUS</th>";
                                    echo "<th>DATE</th>";
                                    echo "<th>ACTION</th>";

                                    echo "</tr>";
                                    echo "</thead>";


                                    ?>
                                    <?php



                                    $count = 1;
                                    echo "<tbody>";
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        echo "<tr class='record'>";

                                        $encoded_id = base64_encode($row['admission_id']); // Encode the category ID

                                        echo "<td><input type='checkbox' class='menuCheckbox' name='advt_ids[]' value='$encoded_id'></td>";

                                        echo "<td>$count</td>";
                                        echo "<td>" . $row['name'] . "</td>";
                                     
                                        echo "<td>" . $row['mobile'] . "</td>";
                                        echo "<td>" . $row['course_type'] . "</td>";
                                        echo "<td>" . $row['state'] . "</td>";
                                        echo "<td>" . $row['city'] . "</td>";
                                           echo "<td>" . $row['remarks'] . "</td>";
                                        $status = strtolower($row['lead_status']); // Convert to lowercase for easier comparison

                                        $badgeMap = [
                                            'untouched' => '#FF0B55',
                                            'verified' => '#28a745',
                                            'hot' => '#E52020',
                                            'cold' => '#17a2b8',
                                            'followup' => '#FE7743',
                                            'warm' => '#FFB22C',
                                            'not answering' => '#A76545',
                                            'call after sometime' => '#ffc107',
                                            'not reached' => '#854836',
                                            'lead own' => '#096B68'
                                        ];
                                        $badgeColor = $badgeMap[$status] ?? '#6c757d';
                                        $textColor = '#fff';


                                        echo "<td><span class='badge' style='font-size:14px; background-color: $badgeColor; color: $textColor;'>" . ucfirst($status) . "</span></td>";


                                        echo "<td>" . date("d-m-Y", strtotime($row['date'])) . "</td>";




                                        echo "<td>
                                                <a href='javascript:void(0)' class='btn btn-warning viewLead' data-id='$encoded_id'>
                                                    <i class='feather icon-eye'></i> 
                                                </a>

                                                <a href='javascript:void(0)' 
                                                class='btn btn-success editLead' 
                                                data-lead-id='$encoded_id' 
                                                data-status='" . htmlspecialchars($row['lead_status']) . "'
                                                data-remark='" . htmlspecialchars($row['remarks']) . "'>
                                                <i class='feather icon-edit'></i>
                                                </a>

                                            <a href='javascript:void(0)' class='btn btn-danger delete-btn' data-id='<?= $encoded_id ?>' data-bs-toggle='modal' data-bs-target='#deleteModal'>
    <i class='feather icon-trash'></i> 
</a>



                                            </td>";


                                        echo "</tr>";


                                        echo "</tr>";

                                        $count++;
                                    }

                                    echo "</tbody>";
                                    echo "</table>";

                                    ?>





                                </div>
                                <br />
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Modal -->
    <div class="modal fade" id="viewLeadModal" tabindex="-1" aria-labelledby="viewLeadModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="viewLeadModalLabel">Lead Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">X</button>
                </div>
                <div class="modal-body" id="leadDetails">
                    Loading details...
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Lead Status Modal -->
    <div class="modal" id="editLeadStatusModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Update Lead Status</h4>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">X</button>
                </div>
                <div class="modal-body">
                    <form method="post">
                        <input type="hidden" id="admission_id" name="admission_id">
                        <div class="form-group">
                            <label for="lead_status">Lead Status:</label>
                            <select id="lead_status" name="lead_status" class="form-control">
                                <!-- Options will be dynamically loaded here -->
                            </select>
                        </div>

                        <div class="form-group mt-3">
                            <label for="remarks">Remarks:</label>
                            <textarea id="remarks" name="remarks" class="form-control" rows="3" placeholder="Enter remarks..."></textarea>
                        </div>

                        <button type="submit" name="editleads" class="btn btn-primary">Update</button>
                    </form>

                </div>
            </div>
        </div>
    </div>

    <!-- Modal for Displaying Filtered Leads -->
    <div class="modal fade" id="viewFilteredLeadsModal" tabindex="-1" aria-labelledby="viewFilteredLeadsModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="viewFilteredLeadsModalLabel">Filtered Leads</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">X</button>
                </div>
                <div class="modal-body" id="filteredLeadsResults">
                    <!-- Filtered leads will be shown here in a table -->
                </div>
            </div>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">Delete Selected Leads</h5>
                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            
            <div class="modal-body">
                Are you sure you want to delete the selected leads?
                <input type="hidden" id="deleteId">
            </div>
            
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" id="confirmDelete">Delete</button>
            </div>
            
        </div>
    </div>
</div>

    <script src="assets/js/vendor-all.min.js"></script>
    <!-- <script src="assets/js/plugins/bootstrap.min.js"></script> -->
    <script src="assets/js/pcoded.min.js"></script>
    <!--<script src="assets/js/menu-setting.min.js"></script>-->
    <script src="assets/js/plugins/jquery.dataTables.min.js"></script>
    <script src="assets/js/plugins/dataTables.bootstrap4.min.js"></script>
    <script src="assets/js/plugins/buttons.colVis.min.js"></script>
    <script src="assets/js/plugins/buttons.print.min.js"></script>
    <script src="assets/js/plugins/pdfmake.min.js"></script>
    <script src="assets/js/plugins/jszip.min.js"></script>
    <script src="assets/js/plugins/dataTables.buttons.min.js"></script>
    <script src="assets/js/plugins/buttons.html5.min.js"></script>
    <script src="assets/js/plugins/buttons.bootstrap4.min.js"></script>
    <!-- <script src="assets/js/pages/data-export-custom.js"></script> -->
    <!-- jQuery (Ensure it is loaded first) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/2.3.0/js/dataTables.js"></script>
    <script>
        let table = new DataTable('#leadsTable');
    </script>
    <!-- SweetAlert2 JS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.0/dist/sweetalert2.min.js"></script>

    <!-- Bootstrap Bundle (Includes Popper.js and Bootstrap JS) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        $(document).ready(function() {
            $("#updateuser").delay(5000).slideUp(300);
        });
    </script>



    <script>
        // JavaScript to handle deletion of selected categories
        document.getElementById("deleteSelected").addEventListener("click", function() {
            var form = document.getElementById("deleteForm");
            var checkboxes = form.querySelectorAll("input[type=checkbox]:checked");

            // Check if any checkboxes are selected
            if (checkboxes.length === 0) {
                alert("Please select at least one user to delete.");
            } else {
                // Show the delete confirmation modal
                $('#deleteModal').modal('show');
            }
        });

        // JavaScript to confirm deletion when the "Delete" button is clicked in the modal
        document.getElementById("confirmDelete").addEventListener("click", function() {
            var form = document.getElementById("deleteForm");
            form.submit(); // Submit the form to delete the selected users
        });
    </script>

    <script>
        function toggleCheckboxes(source) {
            const checkboxes = document.querySelectorAll('.menuCheckbox');
            checkboxes.forEach(checkbox => {
                checkbox.checked = source.checked;
            });
        }
    </script>
    <script>
        $(document).on('click', '.viewLead', function() {
            var encodedId = $(this).data('id'); // Get the encoded ID from the button

            // Show the modal
            var modal = new bootstrap.Modal(document.getElementById('viewLeadModal'));
            modal.show();

            // Fetch details with AJAX
            $.ajax({
                url: 'fetch-lead-details.php', // Backend script
                type: 'POST',
                data: {
                    id: encodedId
                },
                success: function(response) {
                    // Populate modal body with response
                    $('#leadDetails').html(response);
                },
                error: function() {
                    $('#leadDetails').html('<p>Error fetching details.</p>');
                }
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            $(document).on("click", ".editLead", function() {
                let admissionId = $(this).data("lead-id");
                let currentStatus = $(this).data("status")?.toLowerCase().trim();
                let remark = $(this).data("remark");

                $("#admission_id").val(admissionId);
                $("#remarks").val(remark);

                // Fetch lead status options
                $.ajax({
                    url: "fetch_lead_status.php",
                    method: "GET",
                    success: function(data) {
                        $("#lead_status").html(data);

                        // Find and select the matching option
                        $("#lead_status option").each(function() {
                            if ($(this).val().toLowerCase().trim() === currentStatus) {
                                $(this).prop("selected", true);
                                return false;
                            }
                        });

                        $("#editLeadStatusModal").modal("show");
                    },
                    error: function() {
                        alert("Error fetching lead statuses.");
                    }
                });
            });
        });
    </script>

    <script>
        $(document).ready(function() {
            // Populate the dropdown with lead statuses
            $.ajax({
                url: 'fetch_lead_status.php', // Endpoint to fetch the statuses
                type: 'GET',
                success: function(response) {
                    $('#statusFilter').append(response); // Append the fetched options to the dropdown
                }
            });

            // On change of filter or date inputs
            $('#statusFilter, #dateFrom, #dateTo').on('change', function() {
                var selectedStatus = $('#statusFilter').val(); // Get selected status
                var dateFrom = $('#dateFrom').val(); // Get selected "Date From"
                var dateTo = $('#dateTo').val(); // Get selected "Date To"

                // Fetch and display filtered leads in the table
                fetchLeads(selectedStatus, dateFrom, dateTo);
            });

            // Function to fetch leads based on filters
            function fetchLeads(status, dateFrom, dateTo) {
                $.ajax({
                    url: 'fetch_filtered_leads.php', // Backend script to fetch leads
                    type: 'POST',
                    data: {
                        status: status,
                        dateFrom: dateFrom,
                        dateTo: dateTo
                    }, // Send selected filters to the backend
                    success: function(response) {
                        $('#leadsTable tbody').html(response); // Update the table body with the filtered leads
                    },
                    error: function() {
                        $('#leadsTable tbody').html('<tr><td colspan="11">Error fetching leads.</td></tr>');
                    }
                });
            }
        });
    </script>

    <script>
        if (window.history.replaceState) {
            window.history.replaceState(null, null, window.location.href);
        }
    </script>
    <!-- Auto-submit on file selection -->
    <script>
        document.getElementById('csv_file').addEventListener('change', function() {
            document.getElementById('leadForm').submit();
        });
    </script>
    <!-- Your custom JS code -->
    <script>
        <?php if ($uploadSuccess): ?>
            Swal.fire({
                title: 'Success!',
                text: 'Leads uploaded successfully.',
                icon: 'success',
                confirmButtonText: 'OK'
            }).then(function() {
                window.location = 'admission-leads.php'; // Optional: Redirect to another page
            });
        <?php endif; ?>
    </script>
    <script>
    // When trash icon is clicked
    document.querySelectorAll('.delete-btn').forEach(function(button) {
        button.addEventListener('click', function () {
            const id = this.getAttribute('data-id');
            document.getElementById('deleteId').value = id;
        });
    });

    // When Delete button in modal is clicked
    document.getElementById('confirmDelete').addEventListener('click', function () {
        const id = document.getElementById('deleteId').value;
        if (id) {
            window.location.href = 'delete-leads.php?id=' + encodeURIComponent(id);
        } else {
            alert('No ID found to delete.');
        }
    });
</script>


</body>

</html>