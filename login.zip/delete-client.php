<?php
include 'db/config.php'; // Your DB connection

if (isset($_POST['delete']) && isset($_POST['client_id'])) {
    $encoded_id = $_POST['client_id'];
    $client_id = base64_decode($encoded_id);

    $query = "UPDATE clients SET is_deleted = 1 WHERE client_id = $client_id";
    if (mysqli_query($db, $query)) {
        header("Location: manage-client.php?status=" . base64_encode("deleted"));
        exit;
    } else {
        echo "Error: " . mysqli_error($db);
    }
} else {
    echo "Invalid request.";
}
?>
