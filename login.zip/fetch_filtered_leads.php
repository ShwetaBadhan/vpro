<?php
include('db/config.php'); // Include the database connection

if (isset($_POST['status']) || isset($_POST['dateFrom']) || isset($_POST['dateTo'])) {
    $status_id = isset($_POST['status']) ? $_POST['status'] : '';
    $date_from = isset($_POST['dateFrom']) ? $_POST['dateFrom'] : '';
    $date_to = isset($_POST['dateTo']) ? $_POST['dateTo'] : '';

    // Base query
    $query = "
    SELECT 
    admission_enquiry.admission_id,
    admission_enquiry.name,

    admission_enquiry.mobile,
   	admission_enquiry.course_type,
    admission_enquiry.state,
    admission_enquiry.city,
        admission_enquiry.remarks,
    admission_enquiry.lead_status,

    admission_enquiry.date
FROM 
    admission_enquiry


    WHERE 
        1=1";

    // Append conditions based on filters
    if (!empty($status_id)) {
        $query .= " AND admission_enquiry.lead_status = '$status_id'";
    }

    if (!empty($date_from)) {
        $query .= " AND admission_enquiry.date >= '$date_from'";
    }

    if (!empty($date_to)) {
        $query .= " AND admission_enquiry.date <= '$date_to'";
    }

    // Execute query
    $query .= " ORDER BY admission_enquiry.date DESC";
    $result = mysqli_query($db, $query);

    // Generate table rows
    if ($result && $result->num_rows > 0) {
        $count = 1;
        while ($row = $result->fetch_assoc()) {
            $encoded_id = base64_encode($row['admission_id']); // Encode the ID

            echo "<tr>";
            echo "<td><input type='checkbox' class='menuCheckbox' name='advt_ids[]' value='$encoded_id'></td>";
            echo "<td>$count</td>";
            echo "<td>" . $row['name'] . "</td>";
    
            echo "<td>" . $row['mobile'] . "</td>";
            echo "<td>" . $row['course_type'] . "</td>";
            echo "<td>" . $row['state'] . "</td>";
            echo "<td>" . $row['city'] . "</td>";
            echo "<td>" . $row['remarks'] . "</td>";
            $status = strtolower($row['lead_status']); // Normalize status name

            $badgeMap = [
                'untouched' => '#FF0B55',
                'verified' => '#28a745',
                'hot' => '#E52020',
                'cold' => '#17a2b8',
                'followup' => '#FE7743',
                'warm' => '#FFB22C',
                'not answering' => '#A76545',
                'call after sometime' => '#ffc107',
                'not reached' => '#854836',
                'lead own' => '#096B68'
            ];
            $badgeColor = $badgeMap[$status] ?? '#6c757d';
            $textColor = '#fff';


            // Output table cell with colored badge
            echo "<td><span class='badge' style='font-size:14px; background-color: $badgeColor; color: $textColor;'>" . ucfirst($status) . "</span></td>";

            echo "<td>" . date("d-m-Y", strtotime($row['date'])) . "</td>";
            echo "<td>
                <a href='javascript:void(0)' class='btn btn-warning viewLead' data-id='$encoded_id'>
                    <i class='feather icon-eye'></i>
                </a>
               <a href='javascript:void(0)' 
                                                class='btn btn-success editLead' 
                                                data-lead-id='$encoded_id' 
                                                data-status='" . htmlspecialchars($row['lead_status']) . "'
                                                data-remark='" . htmlspecialchars($row['remarks']) . "'>
                                                <i class='feather icon-edit'></i>
                                                </a>
                <a href='delete-leads.php?id=$encoded_id' class='btn btn-danger' onclick='return confirm(\"Are you sure you want to delete this lead?\")'>
                    <i class='feather icon-trash'></i>
                </a>
            </td>";
            echo "</tr>";

            $count++;
        }
    } else {
        echo "<tr><td colspan='11'>No leads found matching the selected criteria.</td></tr>";
    }
} else {
    echo "<tr><td colspan='11'>Invalid request. Please select a filter.</td></tr>";
}
