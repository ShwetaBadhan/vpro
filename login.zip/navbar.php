<?php
$adminID = $_SESSION['login_user_id'];
$adminPermissionQuery = "SELECT nm.title FROM admin_permissions ap
inner join navigation_menus nm on ap.navigation_menu_id = nm.id where ap.admin_id='" . $adminID . "' ";
$adminPermissionResult = mysqli_query($db, $adminPermissionQuery);

$permissions = [];
while ($item = mysqli_fetch_row($adminPermissionResult)) {
    array_push($permissions, $item[0]);
}
?>
<nav class="pcoded-navbar menupos-fixed menu-light ">
    <div class="navbar-wrapper  ">
        <div class="navbar-content scroll-div ">
            <ul class="nav pcoded-inner-navbar ">
                <li class="nav-item pcoded-menu-caption">
                    <label>Navigation</label>
                </li>
                <li class="nav-item">
                    <a href="dashboard.php" class="nav-link " style="background:#192f59; color:#fff;"><span
                            class="pcoded-micon"><i class="feather icon-home"></i></span><span
                            class="">Dashboard</span></a>
                </li>
                <!-- <?php if ((in_array('Admission Leads', $permissions)) || (in_array('All', $permissions))
                        ) {
                        ?>
               		 <li class="nav-item">
                    	<a href="admission-leads.php" class="nav-link "><span class="pcoded-micon"><i class="feather icon-lock"></i></span><span class="">Admission Leads</span></a>
                	</li>
                	<?php } ?> -->
                <?php if ((in_array('All Admission Leads', $permissions)) || (in_array('All', $permissions))
                ) {
                ?>
                    <li class="nav-item pcoded-hasmenu">
                        <a href="#!" class="nav-link "><span class="pcoded-micon"><i
                                    class="feather icon-edit"></i></span><span class="pcoded-mtext">Leads</span></a>
                        <ul class="pcoded-submenu">
                            <?php

                            if ((in_array('All Leads', $permissions)) || (in_array('All', $permissions))) {
                                echo "<li><a href='admission-leads.php'>All Leads</a></li>";
                            }
                            if ((in_array('Verified Leads', $permissions)) || (in_array('All', $permissions))) {
                                echo "<li><a href='verify-leads.php'>Verified Leads</a></li>";
                            }
                            if ((in_array('Hot Leads', $permissions)) || (in_array('All', $permissions))) {
                                echo "<li><a href='hot-leads.php'>Hot Leads</a></li>";
                            }
                            if ((in_array('Warm Leads', $permissions)) || (in_array('All', $permissions))) {
                                echo "<li><a href='warm-leads.php'>Warm Leads</a></li>";
                            }
                            if ((in_array('Own Leads', $permissions)) || (in_array('All', $permissions))) {
                                echo "<li><a href='own-leads.php'>Own Leads</a></li>";
                            }

                            ?>
                        </ul>
                    </li>
                <?php } ?>
                <?php if ((in_array('Recycle Bin', $permissions)) || (in_array('All', $permissions))
                ) {
                ?>
                    <li class="nav-item">
                        <a href="recycle-bin.php" class="nav-link "><span class="pcoded-micon"><i class="feather icon-lock"></i></span><span class="">Recycle Bin</span></a>
                    </li>
                <?php } ?>

                <?php if ((in_array('Add New Service', $permissions)) || (in_array('All Service', $permissions)) || (in_array('All', $permissions))) { ?>
                    <li class="nav-item pcoded-hasmenu">
                        <a href="#!" class="nav-link "><span class="pcoded-micon"><i class="feather icon-briefcase"></i>

                            </span><span class="pcoded-mtext">Services</span></a>
                        <ul class="pcoded-submenu">
                            <?php if ((in_array('Add New Service', $permissions)) || (in_array('All', $permissions))) {
                                echo "<li><a href='add-service.php'>Add New Service</a></li>";
                            }
                            if ((in_array('All Service', $permissions)) || (in_array('All', $permissions))) {
                                echo "<li><a href='manage-service.php'>All Services</a></li>";
                            }
                            ?>
                        </ul>
                    </li>
                <?php } ?>
                <?php if ((in_array('Add New Client', $permissions)) || (in_array('All Client', $permissions)) || (in_array('All Recycle', $permissions)) || (in_array('All', $permissions))) { ?>
                    <li class="nav-item pcoded-hasmenu">
                        <a href="#!" class="nav-link "><span class="pcoded-micon"><i
                                    class="feather icon-user"></i></span><span class="pcoded-mtext">Clients</span></a>
                        <ul class="pcoded-submenu">
                            <?php if ((in_array('Add New Client', $permissions)) || (in_array('All', $permissions))) {
                                echo "<li><a href='add-client.php'>Add New Client</a></li>";
                            }
                            if ((in_array('All Client', $permissions)) || (in_array('All', $permissions))) {
                                echo "<li><a href='manage-client.php'>All Clients</a></li>";
                            }
                            if ((in_array('All Recycle', $permissions)) || (in_array('All', $permissions))) {
                                echo "<li><a href='recycle-client.php'>Recycle Bin</a></li>";
                            }
                            ?>
                        </ul>
                    </li>
                <?php } ?>


                <?php if ((in_array('Tickets', $permissions)) || (in_array('All', $permissions))
                ) {
                ?>
                    <li class="nav-item">
                        <a href="#" class="nav-link "><span class="pcoded-micon"><i class="feather icon-bookmark"></i>

                            </span><span class="">Tickets</span></a>
                    </li>
                <?php } ?>
                <?php if ((in_array('Quote', $permissions)) || (in_array('All', $permissions))
                ) {
                ?>
                    <li class="nav-item">
                        <a href="#" class="nav-link "><span class="pcoded-micon"><i class="feather icon-file-text"></i>
                            </span><span class="">Quotes</span></a>
                    </li>
                <?php } ?>




                <?php if ((in_array('Add New Admin User', $permissions)) || (in_array('All Admin Users', $permissions)) || (in_array('All', $permissions))) { ?>
                    <li class="nav-item pcoded-hasmenu">
                        <a href="#!" class="nav-link "><span class="pcoded-micon"><i
                                    class="feather icon-users"></i></span><span class="pcoded-mtext">Admin Users</span></a>
                        <ul class="pcoded-submenu">
                            <?php if ((in_array('Add New Admin User', $permissions)) || (in_array('All', $permissions))) {
                                echo "<li><a href='add-user.php'>Add New Admin User</a></li>";
                            }
                            if ((in_array('All Admin Users', $permissions)) || (in_array('All', $permissions))) {
                                echo "<li><a href='manage-user.php'>All Admin Users</a></li>";
                            }
                            ?>
                        </ul>
                    </li>
                <?php } ?>






                <?php if ((in_array('Change Password', $permissions)) || (in_array('All', $permissions))
                ) {
                ?>
                    <li class="nav-item">
                        <a href="changepass.php" class="nav-link "><span class="pcoded-micon"><i class="feather icon-lock"></i></span><span class="">Change Password</span></a>
                    </li>
                <?php } ?>

                <?php if ((in_array('General Settings', $permissions)) || (in_array('Website Settings', $permissions)) || (in_array('System Settings', $permissions)) || (in_array('Financial Settings', $permissions)) || (in_array('All', $permissions))) { ?>
                    <li class="nav-item pcoded-hasmenu">
                        <a href="#!" class="nav-link "><span class="pcoded-micon"><i
                                    class="feather icon-settings"></i></span><span class="pcoded-mtext">Settings
                            </span></a>
                        <ul class="pcoded-submenu">

                            <?php if ((in_array('General Settings', $permissions)) || (in_array('All', $permissions))) {
                                echo "<li><a href='profile.php'>General Settings</a></li>";
                            }
                            // if ((in_array('Website Settings', $permissions)) || (in_array('All', $permissions))) {
                            // echo "<li><a href='company-settings.php'>Website Settings</a></li>";
                            // }
                            if ((in_array('System Settings', $permissions)) || (in_array('All', $permissions))) {
                                echo "<li><a href='system-settings.php'>System Settings</a></li>";
                            }
                            // if ((in_array('Financial Settings', $permissions)) || (in_array('All', $permissions))) {
                            //     echo "<li><a href='financial-settings.php'>Financial Settings</a></li>";
                            // }
                            ?>
                        </ul>
                    </li>
                <?php } ?>


                <li class="nav-item">
                    <a href="logout.php" class="nav-link " style="background:#192f59; color:#fff;"><span
                            class="pcoded-micon"><i class="feather icon-power"></i></span><span class="">Log
                            out</span></a>
                </li>

            </ul>


        </div>
    </div>
</nav>