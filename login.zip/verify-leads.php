<?php
error_reporting(E_ALL);
session_start();

if (!isset($_SESSION["login_user"])) {
    header("location: index.php");
}

include("db/config.php");
$query = "
SELECT 
    admission_enquiry.admission_id,
    admission_enquiry.name,
    admission_enquiry.email,
    admission_enquiry.mobile,
    admission_enquiry.course_type,
    admission_enquiry.state,
    admission_enquiry.city,
    admission_enquiry.lead_status,
    admission_enquiry.remarks,
    admission_enquiry.date
FROM 
    admission_enquiry

WHERE 
    admission_enquiry.lead_status = 'verified'
ORDER BY 
    admission_enquiry.date DESC";
$result = mysqli_query($db, $query);
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['editleads'])) {
    $leadid = base64_decode($_POST['admission_id']);
    $leadstatus = $_POST['lead_status'];
    $remarks = trim($_POST['remarks']); // Get remarks

    if (empty($leadstatus)) {
        die("Lead status is required.");
    }

    $query = "UPDATE admission_enquiry SET lead_status = ?, remarks = ? WHERE admission_id = ?";

    if ($stmt = mysqli_prepare($db, $query)) {
        mysqli_stmt_bind_param($stmt, "ssi", $leadstatus, $remarks, $leadid);

        if (mysqli_stmt_execute($stmt)) {
            header('Location: hot-leads.php');
            exit;
        } else {
            echo "Error updating lead status: " . mysqli_error($db);
        }

        mysqli_stmt_close($stmt);
    } else {
        echo "Error preparing statement: " . mysqli_error($db);
    }
}
// Fetch lead statuses
$query = "SELECT status_id, status_name FROM lead_status";
$status_result = mysqli_query($db, $query);

?>

<!DOCTYPE html>
<html lang="en">

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />

<head>
    <title>Admission Leads</title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="description" content="" />
    <meta name="keywords" content="">
    <meta name="author" content="Codedthemes" />

    <link rel="icon" href="assets/images/favicon.ico" type="image/x-icon">



    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/2.3.0/css/dataTables.dataTables.css" />
</head>

<body class="">

    <div class="loader-bg">
        <div class="loader-track">
            <div class="loader-fill"></div>
        </div>
    </div>

    <!-- Header -->
    <?php
    include("header.php");
    ?>
    <!-- /Header -->

    <!-- navbar -->
    <?php
    include("navbar.php");
    ?>
    <!-- /navbar -->

    <section class="pcoded-main-container">
        <div class="pcoded-content">

            <div class="page-header">
                <div class="page-block">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="page-header-title">
                                <h5 class="m-b-10">Admission Lead
                                </h5>
                            </div>
                            <!-- 							<ul class="breadcrumb"> -->
                            <!--                                 <li class="breadcrumb-item"><a href="index.php"><i class="feather icon-home"></i></a> -->
                            <!--                                 </li> -->
                            <!--                             </ul> -->
                        </div>
                    </div>
                </div>
            </div>


            <div class="row">

                <div class="col-sm-12">
                    <div class="card">
                        <div class="card-header table-card-header">
                        </div>
                        <div class="card-body">
                            <form id="deleteForm" action="delete-leads.php" method="post">
                                <button type="button" id="deleteSelected" class="btn btn-danger mb-2"><i class='feather icon-trash'></i> Delete Selected</button>
                                <!-- <a href="download-leads.php" type="button" id="" class="btn btn-success mb-2"><i class='feather icon-download'></i> Download</a> -->
                                <div class="dt-responsive table-responsive">

                                    <?php

                                    if (isset($_GET['status'])) {
                                        $st = $_GET['status'];
                                        $st1 = base64_decode($st);

                                        if ($st1 > 0) {
                                            echo " <div class='alert alert-success alert-dismissible fade show' role='alert' style='font-size:16px;' id='updateuser'>
  <strong><i class='feather icon-check'></i>Success!</strong>  Data has been Deleted Successfully.
  <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
    <span aria-hidden='true'>&times;</span>
  </button>
</div> ";
                                        } else {

                                            echo " <div class='alert alert-danger alert-dismissible fade show' role='alert' style='font-size:16px;' id='updateuser'>
  <strong>Error!</strong> Client has been not Updated
  <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
    <span aria-hidden='true'>&times;</span>
  </button>
</div> ";
                                        }
                                    }

                                    ?>

                                    <?php
                                    //                                 echo '<a href="javascript:void(0)" id="basic-btn" class="btn btn-warning">
                                    //     <i class="feather icon-download"></i> Download Excel
                                    // </a>';
                                    echo '<table id="myTable" class="table table-striped table-bordered nowrap">';
                                    echo "<thead>";
                                    echo "<tr>";
                                    echo "<th><input type='checkbox' id='selectAll' onclick='toggleCheckboxes(this)'> SELECT</th>";
                                    echo "<th>SNO</th>";
                                    echo "<th>NAME</th>";
                                    
                                    echo "<th>MOBILE NUMBER</th>";
                                    echo "<th>COURSES</th>";
                                    echo "<th>STATE</th>";
                                    echo "<th>CITY</th>";
                                    echo "<th>REMARKS </th>";
                                    echo "<th>LEAD STATUS</th>";
                                    echo "<th>DATE</th>";
                                    echo "<th>ACTION</th>";

                                    echo "</tr>";
                                    echo "</thead>";


                                    ?>
                                    <?php



                                    $count = 1;
                                    echo "<tbody>";
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        echo "<tr class='record'>";

                                        $encoded_id = base64_encode($row['admission_id']); // Encode the category ID

                                        echo "<td><input type='checkbox' class='menuCheckbox' name='advt_ids[]' value='$encoded_id'></td>";

                                         echo "<td>$count</td>";
                                        echo "<td>" . $row['name'] . "</td>";
                                       
                                        echo "<td>" . $row['mobile'] . "</td>";
                                        echo "<td>" . $row['course_type'] . "</td>";
                                        echo "<td>" . $row['state'] . "</td>";
                                        echo "<td>" . $row['city'] . "</td>";
                                         echo "<td>" . $row['remarks'] . "</td>";
                                        $status = strtolower($row['lead_status']); // Convert to lowercase for easier comparison

                                        $badgeMap = [
                                            'untouched' => '#FF0B55',
                                            'verified' => '#28a745',
                                            'hot' => '#E52020',
                                            'cold' => '#17a2b8',
                                            'followup' => '#FE7743',
                                            'warm' => '#FFB22C',
                                            'not answering' => '#A76545',
                                            'call after sometime' => '#ffc107',
                                            'not reached' => '#854836',
                                            'lead own' => '#096B68'
                                        ];
                                        $badgeColor = $badgeMap[$status] ?? '#6c757d';
                                        $textColor = '#fff';


                                        echo "<td><span class='badge' style='font-size:14px; background-color: $badgeColor; color: $textColor;'>" . ucfirst($status) . "</span></td>";


                                        echo "<td>" . date("d-m-Y", strtotime($row['date'])) . "</td>";


                                        echo "<td>
    <a href='javascript:void(0)' class='btn btn-warning viewLead' data-id='$encoded_id'>
    <i class='feather icon-eye'></i> 
    </a>

 <a href='javascript:void(0)' 
                                                class='btn btn-success editLead' 
                                                data-lead-id='$encoded_id' 
                                                data-status='" . htmlspecialchars($row['lead_status']) . "'
                                                data-remark='" . htmlspecialchars($row['remarks']) . "'>
                                                <i class='feather icon-edit'></i>
                                                </a>


<a href='javascript:void(0)' class='btn btn-danger delete-btn' data-id='<?= $encoded_id ?>' data-bs-toggle='modal' data-bs-target='#deleteModal'>
    <i class='feather icon-trash'></i> 
</a>

    </td>";

                                        echo "</tr>";


                                        echo "</tr>";

                                        $count++;
                                    }

                                    echo "</tbody>";
                                    echo "</table>";

                                    ?>





                                </div>
                                <br />
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Modal -->
    <div class="modal fade" id="viewLeadModal" tabindex="-1" aria-labelledby="viewLeadModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="viewLeadModalLabel">Lead Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">X</button>
                </div>
                <div class="modal-body" id="leadDetails">
                    Loading details...
                </div>
            </div>
        </div>
    </div>
    <!-- Edit Lead Status Modal -->
    <div class="modal" id="editLeadStatusModal">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Update Lead Status</h4>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">X</button>
                </div>
                <div class="modal-body">
                    <form method="post">
                        <input type="hidden" id="admission_id" name="admission_id">
                        <div class="form-group">
                            <label for="lead_status">Lead Status:</label>
                            <select id="lead_status" name="lead_status" class="form-control">
                                <!-- Options will be dynamically loaded here -->
                            </select>
                        </div>

                        <div class="form-group mt-3">
                            <label for="remarks">Remarks:</label>
                            <textarea id="remarks" name="remarks" class="form-control" rows="3" placeholder="Enter remarks..."></textarea>
                        </div>

                        <button type="submit" name="editleads" class="btn btn-primary">Update</button>
                    </form>

                </div>
            </div>
        </div>
    </div>
 <!-- Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">Delete Selected Leads</h5>
                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            
            <div class="modal-body">
                Are you sure you want to delete the selected leads?
                <input type="hidden" id="deleteId">
            </div>
            
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" id="confirmDelete">Delete</button>
            </div>
            
        </div>
    </div>
</div>

    <script src="assets/js/vendor-all.min.js"></script>
    <!-- <script src="assets/js/plugins/bootstrap.min.js"></script> -->
    <script src="assets/js/pcoded.min.js"></script>
    <!--<script src="assets/js/menu-setting.min.js"></script>-->
    <script src="assets/js/plugins/jquery.dataTables.min.js"></script>
    <script src="assets/js/plugins/dataTables.bootstrap4.min.js"></script>
    <script src="assets/js/plugins/buttons.colVis.min.js"></script>
    <script src="assets/js/plugins/buttons.print.min.js"></script>
    <script src="assets/js/plugins/pdfmake.min.js"></script>
    <script src="assets/js/plugins/jszip.min.js"></script>
    <script src="assets/js/plugins/dataTables.buttons.min.js"></script>
    <script src="assets/js/plugins/buttons.html5.min.js"></script>
    <script src="assets/js/plugins/buttons.bootstrap4.min.js"></script>
    <!-- <script src="assets/js/pages/data-export-custom.js"></script> -->
    <!-- jQuery (Ensure it is loaded first) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/2.3.0/js/dataTables.js"></script>
    <script>
        let table = new DataTable('#myTable');
    </script>
    <!-- Bootstrap Bundle (Includes Popper.js and Bootstrap JS) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        $(document).ready(function() {
            $("#updateuser").delay(5000).slideUp(300);
        });
    </script>

    <script type="text/javascript">
        $(function() {
            $(".delbutton").click(function() {

                var element = $(this);

                var del_id = element.attr("id");

                var info = 'id=' + del_id;
                if (confirm("Are you sure you want to delete this Record?")) {
                    $.ajax({
                        type: "GET",
                        url: "deleteuser.php",
                        data: info,
                        success: function() {}
                    });
                    $(this).parents(".record").animate({
                            backgroundColor: "#FF3"
                        }, "fast")
                        .animate({
                            opacity: "hide"
                        }, "slow");
                }
                return false;
            });
        });
    </script>

    <script>
        // JavaScript to handle deletion of selected categories
        document.getElementById("deleteSelected").addEventListener("click", function() {
            var form = document.getElementById("deleteForm");
            var checkboxes = form.querySelectorAll("input[type=checkbox]:checked");
            if (checkboxes.length === 0) {
                alert("Please select at least one user to delete.");
            } else {
                if (confirm("Are you sure you want to delete the selected users?")) {
                    form.submit();
                }
            }
        });
    </script>
    <script>
        function toggleCheckboxes(source) {
            const checkboxes = document.querySelectorAll('.menuCheckbox');
            checkboxes.forEach(checkbox => {
                checkbox.checked = source.checked;
            });
        }
    </script>
    <script>
        $(document).on('click', '.viewLead', function() {
            var encodedId = $(this).data('id'); // Get the encoded ID from the button

            // Show the modal
            var modal = new bootstrap.Modal(document.getElementById('viewLeadModal'));
            modal.show();

            // Fetch details with AJAX
            $.ajax({
                url: 'fetch-lead-details.php', // Backend script
                type: 'POST',
                data: {
                    id: encodedId
                },
                success: function(response) {
                    // Populate modal body with response
                    $('#leadDetails').html(response);
                },
                error: function() {
                    $('#leadDetails').html('<p>Error fetching details.</p>');
                }
            });
        });
    </script>
    <script>
        $(document).ready(function() {
            $(document).on("click", ".editLead", function() {
                let admissionId = $(this).data("lead-id");
                let currentStatus = $(this).data("status")?.toLowerCase().trim();
                let remark = $(this).data("remark");

                $("#admission_id").val(admissionId);
                $("#remarks").val(remark);

                // Fetch lead status options
                $.ajax({
                    url: "fetch_lead_status.php",
                    method: "GET",
                    success: function(data) {
                        $("#lead_status").html(data);

                        // Find and select the matching option
                        $("#lead_status option").each(function() {
                            if ($(this).val().toLowerCase().trim() === currentStatus) {
                                $(this).prop("selected", true);
                                return false;
                            }
                        });

                        $("#editLeadStatusModal").modal("show");
                    },
                    error: function() {
                        alert("Error fetching lead statuses.");
                    }
                });
            });
        });
    </script>
    <script>
        if (window.history.replaceState) {
            window.history.replaceState(null, null, window.location.href);
        }
    </script>
      <script>
    // When trash icon is clicked
    document.querySelectorAll('.delete-btn').forEach(function(button) {
        button.addEventListener('click', function () {
            const id = this.getAttribute('data-id');
            document.getElementById('deleteId').value = id;
        });
    });

    // When Delete button in modal is clicked
    document.getElementById('confirmDelete').addEventListener('click', function () {
        const id = document.getElementById('deleteId').value;
        if (id) {
            window.location.href = 'delete-leads.php?id=' + encodeURIComponent(id);
        } else {
            alert('No ID found to delete.');
        }
    });
</script>

</body>

</html>